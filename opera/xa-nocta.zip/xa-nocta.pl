#!/usr/bin/perl -w 
# xa-nocta -- XA No-Click-To-Activate patchscript v1.8.1.2 / 2012-09-05
#
# Portions copyright (C) by XA, XI 2010 - VIII 2012.
# Licensed under a Creative Commons CC-by-nc-sa 3.0 Unported license.
# Works (including, but not limited to, new patch byte patterns) that merely
# extend or make use of the Package, do not, by themselves, cause the Package
# to be a Derivative. In addition, such works are not considered parts of the
# Package itself, and are not subject to the terms of the granted license.
# As far as applicable, the included patch byte patterns shall be considered
# licensed under a Creative Commons CC0 1.0 Universal license.
#
# Based on work by Rafal / d.i.z and multiple contributors
# on the MyOpera forums and blogs.
#

#use warnings;
#use strict;


###############################################################################
@PATCH_INFO = (
#	{
#		desc =>   'Priority',
#		assert => undef,
#		test =>   undef,
#		match =>  qr/./,
#		replace => undef,
#		patchset => [
#			{
#				desc =>   'Opera 10.x & 10.50 alphas', # just for testing nested patch lists.
#				assert => undef,
#				test =>   qr/\xF7\xD8\x1B\xC0\xB0\x01/s,
#				match =>  qr/\x6A\x17\x59\xE8(.{4})\xF7\xD8\x1B\xC0\xF7\xD8([\x58\x5B])/s,
#				replace => '"\x6A\x17\x59\xE8$1\xF7\xD8\x1B\xC0\xB0\x01$2"'
#			},
#		]
#	},
	{
		desc =>   'Generic',
		assert => undef,
		test =>   undef,
		match =>  qr/./,
		replace => undef,
		patchset => [
			{
				# contributors: PX
				desc =>   'Opera Next 12.50 64-bit [1497,1513,1538]',
				assert => undef,
				test =>   qr/\x41\xb1\x01\xba\xb1\x02\x00\x00\x45\x8d\x41\x17[\xe8\xe9]/s,
				match =>  qr/(\x45\x33\xc9)(\xba\xb1\x02\x00\x00\x45\x8d\x41\x17[\xe8\xe9])/s,
				replace => '"\x41\xb1\x01$2"'
			},
			{
				# contributors: PX
				desc =>   'Opera 12.00-12.02 64-bit',
				assert => undef,
				test =>   qr/\x41\xb1\x01\xba\xae\x02\x00\x00\x45\x8d\x41\x17[\xe8\xe9]/s,
				match =>  qr/(\x45\x33\xc9)(\xba\xae\x02\x00\x00\x45\x8d\x41\x17[\xe8\xe9])/s,
				replace => '"\x41\xb1\x01$2"'
			},
			{
				# contributors: BtEO [20120426], XA [20120426]
				desc =>   'Opera 12.00 32bit [1359,1360,1372,1380,1383,1385,1386,1387,1406,1413,1417,1422,1424,1429,1431,1433,1438,1439,1440,1441,1445,1448,1450,1454,1456,1465,1467], 12.01 32bit [1473,1486,1491,1517,1520,1528,1532], 12.50 32bit [1497,1513,1538,1546]',
				assert => undef,
				test =>   qr/\x6A\x01\x6A\x17[\xBF\x68].{4}\xE8.{4}[\x5F\x5E]\xC2\x04\x00.{5}\x6A\x01\x6A\x17[\xBF\x68].{4}\xE8.{4}[\x5F\x5E]\xC2\x04\x00/s,
				match =>  qr/\x6A\x00\x6A\x17([\xBF\x68].{4})\xE8(.{4})([\x5F\x5E])\xC2\x04\x00(.{5})\x6A\x00\x6A\x17([\xBF\x68].{4})\xE8(.{4})([\x5F\x5E])\xC2\x04\x00/s,
				replace => '"\x6A\x01\x6A\x17$1\xE8$2$3\xC2\x04\x00$4\x6A\x01\x6A\x17$5\xE8$6$7\xC2\x04\x00"'
			},
			{
				# contributors: XA [20111207], BtEO [20111219], BtEO [20120210]
				desc =>   'Opera 12.00 [1085,1090,1105,1116,1155,1174,1191,1211,1213,1232;1256,1272,1289,1301,1306,1312,1317,1325,1328,1351_32bit], 11.60 [1134,1139,1144,1145,1147,1150,1159,1163,1169,1173,1177,1178,1180,1181,1184,1185], 11.61 [1222,1234,1236,1250], 11.62 [1273,1297;1301], 11.64 [1403]',
				assert => undef,
				test =>   qr/\x6A\x17\x6A\x01\x6A\x01[\xBF\x68].{4}\xE8.{4}(?:\xF7\xD8\x1B\xC0\xF7\xD8)?[\x5F\x5E]\xC2\x04\x00.{5}\x6A\x17\x6A\x01\x6A\x01[\xBF\x68].{4}\xE8.{4}(?:\xF7\xD8\x1B\xC0\xF7\xD8)?[\x5F\x5E]\xC2\x04\x00/s,
				match =>  qr/\x6A\x17\x6A\x00\x6A\x01([\xBF\x68].{4})\xE8(.{4})((?:\xF7\xD8\x1B\xC0\xF7\xD8)?[\x5F\x5E])\xC2\x04\x00(.{5})\x6A\x17\x6A\x00\x6A\x01([\xBF\x68].{4})\xE8(.{4})((?:\xF7\xD8\x1B\xC0\xF7\xD8)?[\x5F\x5E])\xC2\x04\x00/s,
				replace => '"\x6A\x17\x6A\x01\x6A\x01$1\xE8$2$3\xC2\x04\x00$4\x6A\x17\x6A\x01\x6A\x01$5\xE8$6$7\xC2\x04\x00"'
			},
			{
				# contributors: XA, gwarser
				desc =>   'Opera 11.50 [1024,1027,1031,1035,1036,1037,1040,1049;1052,1054,1065,1067,1068,1071,1073,1074], 11.51 [1084,1087], 11.52 [1100], 12.00 [1017,1020,1027,1033,1039,1042,1047;1054,1060,1065,1076]',
				assert => undef,
				test =>   qr/\x6A\x00\x6A\x01\x6A\x2C\xE8.{4}\xF7\xD8\x1B\xC0\xB0\x01\xC2\x04\x00/s,
				match =>  qr/\x6A\x17\x6A\x00\x6A\x01\x6A\x2C((?:\xFF\x74\x24.)?\xE8)(.{4})\xF7\xD8\x1B\xC0\xF7\xD8\xC2\x04\x00/s,
				replace => '"\x6A\x17\x6A\x00\x6A\x01\x6A\x2C$1$2\xF7\xD8\x1B\xC0\xB0\x01\xC2\x04\x00"'
			},
			#{
			#	# contributors: XA
			#	desc =>   'Opera 12.00 [1085,1090,1105,1116,1155], 11.60 [1134,1139,1144,1145,1147,1150,1159,1163,1169,1173,1177,1178,1180,1181,1184,1185]',
			#	assert => undef,
			#	test =>   qr/\x6A\x17\x6A\x00\x6A\x01[\xBF\x68][\xA0\xA1]\x02\x00\x00\xE8.{4}\xF7\xD8\x1B\xC0\xB0\x01[\x5F\x5E]\xC2\x04\x00/s,
			#	match =>  qr/\x6A\x17\x6A\x00\x6A\x01([\xBF\x68][\xA0\xA1])\x02\x00\x00\xE8(.{4})\xF7\xD8\x1B\xC0\xF7\xD8([\x5F\x5E])\xC2\x04\x00/s,
			#	replace => '"\x6A\x17\x6A\x00\x6A\x01$1\x02\x00\x00\xE8$2\xF7\xD8\x1B\xC0\xB0\x01$3\xC2\x04\x00"'
			#},
			{
				# contributors: d.i.z, ..
				desc =>   'Opera 11.00 [1045,1055,1085,1094,1101,1111,1128,1133]',
				assert => undef,
				test =>   qr/\x66\xBA\x2C\x00\xE8.{4}\xF7\xD8\x1B\xC0\xB0\x01/s,
				match =>  qr/\x66\xBA\x2C\x00\xE8(.{4})\xF7\xD8\x1B\xC0\xF7\xD8/s,
				replace => '"\x66\xBA\x2C\x00\xE8$1\xF7\xD8\x1B\xC0\xB0\x01"'
			},
			{
				# contributors: d.i.z, ..
				desc =>   'Opera 11.00 [1029,1060,1136,1140,1145,1152,1156,1160,1164,1169,1175,1179,1189,1190], 11.10 [2005,2014,2018,2020,2025,2033,2039,2040,2042,2045,2047,2048,2053,2064,2067,2076,2077,2079,2081,2085,2087]',
				assert => undef,
				test =>   qr/\x66\xBA\x2C\x00\x6A\x17\x59\xE8.{4}\xF7\xD8\x1B\xC0\xB0\x01/s,
				match =>  qr/\x66\xBA\x2C\x00\x6A\x17\x59\xE8(.{4})\xF7\xD8\x1B\xC0\xF7\xD8/s,
				replace => '"\x66\xBA\x2C\x00\x6A\x17\x59\xE8$1\xF7\xD8\x1B\xC0\xB0\x01"'
			},
			{
				# contributors: d.i.z, ..
				desc =>   'Opera 10.x, 10.10 [1830], 10.50 [..], 11.00 [1149], 11.10 [2090,2091,2092,2109], 11.50 [1009,1015,1016,1018,1020]',
				assert => undef,
				test =>   qr/\xF7\xD8\x1B\xC0\xB0\x01/s,
				match =>  qr/\x6A\x17\x59\xE8(.{4})\xF7\xD8\x1B\xC0\xF7\xD8([\x58\x5B])/s,
				replace => '"\x6A\x17\x59\xE8$1\xF7\xD8\x1B\xC0\xB0\x01$2"'
			},
			{
				# contributors: d.i.z
				desc =>   'Opera 10.x (early versions\' "Methode 2")',
				assert => undef,
				test =>   qr/\xC3\x33\xC9\x33\xC0\x85\xC9\xB0\x01\x90\x5B\xC3/s,
				match =>  qr/\xC3\x33\xC9\x33\xC0\x85\xC9\x0F\x95\xC0\x5B\xC3/s,
				replace => '"\xC3\x33\xC9\x33\xC0\x85\xC9\xB0\x01\x90\x5B\xC3"'
			},
		]
	},
);
###############################################################################


sub xaGetopt (\%\@) {
	my($xaopt) = shift(@_);
	my($xaoptPlugins) = shift(@_);
	my($argumentative) = 'P';
	my($first,$rest);
	local($_);

	while (@ARGV && ($_ = $ARGV[0]) =~ /^-(.)(.*)/) {
		($first,$rest) = ($1,$2);
		if (index($argumentative,$first) >= 0) {
			if ($rest ne '') {
				shift(@ARGV);
			}
			else {
				shift(@ARGV);
				$rest = shift(@ARGV);# if $ARGV[0] !~ /^-/;
			}
			if ($first eq 'P') {
				push(@$xaoptPlugins, $rest) if $rest;
			}
			else {
				$xaopt->{$first} = $rest || (int($xaopt->{$first})? int($xaopt->{$first}) + 1: 1);
			}
		}
		else {
			$xaopt->{$first} = 1;
			if ($rest ne '') {
				$ARGV[0] = "-$rest";
			}
			else {
				shift(@ARGV);
			}
		}
	}
}

# a hash of options and an array of plugins to load
my %xaoptOptions;
my @xaoptPlugins;

# get options:
# -b -- invoked from batch script: clobbers input file instead of writing to a *_patched file
# [ -P <plugin_module> ]* -- plugins to load
# -p -- scan for plugins (requires CORE::glob and dependencies to be installed!)
xaGetopt(%xaoptOptions, @xaoptPlugins);

if (!!$xaoptOptions{"p"}) {
	for my $xaplugin (eval 'CORE::glob(\'./xa-nocta-plugin*.pl\')') {
		push(@xaoptPlugins, $xaplugin);
	}
}

# load and include plugins and their patch records
eval {
	for my $xaplugin (@xaoptPlugins) {
		print " + Including plugin '$xaplugin'...\n";
		require $xaplugin; # or print " - Error opening plugin $xaplugin!\n";
	}
	1;
} or do {
	#$@
	print " - Error loading all or some of the plugins!\n";
};

# get immediate options:
# binary to patch and optionally [depecated] flag if invoked by batch script
my $OPERABIN = $ARGV[0];
my $invokedByBatch = defined($ARGV[1])? int($ARGV[1]): 0; # 1 - invoked by batch, operate on original file
$invokedByBatch = $xaoptOptions{"b"} if (defined $xaoptOptions{"b"});

# check for existence of binary to patch
if ( !$OPERABIN ) {
	print " - Missing file argument for perl script!\n";
	exit 1;
}

# open patch candidate
open(FILE,'<'.$OPERABIN) or die " - Error opening file $OPERABIN for reading!\n";
binmode FILE;

my($buf, $data, $n);
my $err = 1;

# read content of binary file to buf
while ( ($n = read(FILE, $data, 100000) ) != 0 ) {
	$buf .= $data;
}


PATCH:
foreach my $patchclass (@PATCH_INFO) {
	#print ($patchclass->{desc}); print "\n\n\n";
	if ($patchclass->{assert} and !($buf =~ m/$patchclass->{assert}/) ) {
		print " o Precondition not satisfied for patched of class '". $patchclass->{desc} ."'.\n     Trying next class.\n";
		next PATCH;
	}
	if ($patchclass->{test} and $buf =~ m/$patchclass->{test}/ ) {
		print " - Seems like already patched with class '". $patchclass->{desc} ."'.\n     NOT proceeding.\n";
		next PATCH;
	}
	if (!$patchclass->{match} || ($buf =~ m/$patchclass->{match}/) ) {
		print " + Trying to apply class '". $patchclass->{desc} ."'...\n\n";
		if ($patchclass->{replace}) {
			$buf =~ s/$patchset->{match}/$patchset->{replace}/gee;
			print " * Success!\n\n";
			$err = 0;
			next PATCH;
		}
		else {
			PATCHSET:
			foreach my $patchset (@{$patchclass->{patchset}}) {
				#print ($patchset->{desc}); print "\n\n\n";
				if ($patchset->{assert} and !($buf =~ m/$patchset->{assert}/) ) {
					print " o Precondition not satisfied for patched of class '". $patchclass->{desc} .
							"' / method '". $patchset->{desc} ."'.\n     Trying next method.\n";
					next PATCHSET;
				}
				if ($patchset->{test} and $buf =~ m/$patchset->{test}/) {
					print "   - Seems like already patched with class '" . $patchclass->{desc} .
							"' / method '". $patchset->{desc} ."'.\n     NOT proceeding.\n";
					next PATCH;
				}
				print "   + Trying to apply class '". $patchclass->{desc} .
						"' / method '". $patchset->{desc} ."'...\n";
				if ($buf =~ m/$patchset->{match}/ ) {
					#$_ = "\x66\xBA\x2C\x00\xE8\x00\x00\x00\x00\xF7\xD8\x1B\xC0\xF7\xD8";
					#s/$patchset->{match}/$patchset->{replace}/gee;
					#print ">>>> " . $_;
					$buf =~ s/$patchset->{match}/$patchset->{replace}/gee;
					#print "!!!!!" if $buf =~ m/$patchset->{test}/;
					print "   * Success!\n\n";
					$err = 0;
					next PATCH;
				}
				else {
					#print "\n\n"; #"   . No match.\n\n";
					next PATCHSET;
				}
			}
			print "\n o No match.\n\n";
		}
	}
}

close(FILE);

# return error when no match found
exit 1 if ($err);

# create file with modified buf
if ($invokedByBatch) {
	open(FILE, ">".$OPERABIN) or die " - Error opening file ". $OPERABIN ." for writing!\n";
} else {
	open(FILE, ">".$OPERABIN."_patched") or die " - Error opening file ". $OPERABIN ."_patched for writing!\n";
}
binmode FILE;
print FILE $buf;
close(FILE);
print " * File '". $OPERABIN . ((!$invokedByBatch)?'_patched':'') ."' successfully written.\n";

exit 0;

###############################################################################

__END__

